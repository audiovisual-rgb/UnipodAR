/**
 * Unipod AR — health endpoint (Vercel serverless function)
 *   GET /api/health -> { status, service, version, region, deployment, runtime, uptime, timestamp }
 *
 * Written against the plain Node (req, res) API so the exact same file runs
 * on Vercel Functions and in `npm run dev` locally. No env vars, no secrets.
 */
module.exports = function handler(req, res) {
  const send = (code, payload) => {
    res.statusCode = code;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.end(JSON.stringify(payload));
  };

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.setHeader('Allow', 'GET, HEAD, OPTIONS');
    return res.end();
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(405, { status: 'error', message: 'Method not allowed' });
  }
  if (req.method === 'HEAD') { res.statusCode = 200; return res.end(); }

  return send(200, {
    status: 'ok',
    service: 'unipod-ar',
    version: '1.0.0',
    region: process.env.VERCEL_REGION || (process.env.VERCEL ? 'vercel' : 'local'),
    deployment: process.env.VERCEL_ENV || 'development',
    runtime: 'node ' + process.version,
    uptime: Math.round(process.uptime()),
    timestamp: new Date().toISOString()
  });
};
