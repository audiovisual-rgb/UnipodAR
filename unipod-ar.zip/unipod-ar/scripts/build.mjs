/**
 * Splits the single-file app into a minified dist/ (index.html + styles.css + app.js).
 * The unminified index.html stays the source of truth — this only changes shipping size.
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { transform } from 'esbuild';

const SRC = new URL('../index.html', import.meta.url);
const OUT = new URL('../dist/', import.meta.url);
mkdirSync(OUT, { recursive: true });

const src = readFileSync(SRC, 'utf8');
const styles = [...src.matchAll(/<style>([\s\S]*?)<\/style>/g)].map(m => m[1]).join('\n');
const scripts = [...src.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]).join('\n');

let html = src.replace(/<style>[\s\S]*?<\/style>/g, '').replace(/<script>[\s\S]*?<\/script>/g, '');
html = html
  .replace(/<!--(?!\[)[\s\S]*?-->/g, '')            // strip comments
  .replace(/\n\s*/g, '\n')                          // strip indentation only (keeps inter-element spacing)
  .replace(/\n{2,}/g, '\n')
  .replace('</head>', '<link rel="stylesheet" href="./styles.css">\n</head>')
  .replace('</body>', '<script src="./app.js" defer></script>\n</body>');

const cssMin = await transform(styles, { loader: 'css', minify: true });
const jsMin = await transform(scripts, { loader: 'js', minify: true, legalComments: 'none' });

writeFileSync(new URL('index.html', OUT), html);
writeFileSync(new URL('styles.css', OUT), cssMin.code);
writeFileSync(new URL('app.js', OUT), jsMin.code);

const kb = n => (n / 1024).toFixed(1) + ' KB';
console.log('index.html ', kb(html.length));
console.log('styles.css ', kb(cssMin.code.length));
console.log('app.js     ', kb(jsMin.code.length));
console.log('total      ', kb(html.length + cssMin.code.length + jsMin.code.length),
  ' (source ' + kb(src.length) + ')');
