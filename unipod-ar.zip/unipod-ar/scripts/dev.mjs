/**
 * Local dev server that emulates Vercel: serves dist/ (or ./ for the raw single file)
 * and answers GET /api/health exactly like the serverless function does.
 *   node scripts/dev.mjs [port] [--raw]
 */
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { extname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const health = require('../api/health.js');

const port = Number(process.argv[2]) || 8898;
const raw = process.argv.includes('--raw');
const root = resolve(new URL(raw ? '../' : '../dist/', import.meta.url).pathname);
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png' };

createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/api/health') return health(req, res);
  let file = join(root, decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname));
  if (!existsSync(file)) file = join(root, 'index.html');
  try {
    const body = readFileSync(file);
    res.writeHead(200, { 'Content-Type': types[extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(body);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found');
  }
}).listen(port, '0.0.0.0', () => {
  console.log(`Unipod AR ${raw ? '(raw index.html)' : '(dist build)'} → http://localhost:${port}`);
  console.log(`health endpoint → http://localhost:${port}/api/health`);
});
