# Unipod AR

A working web app for scanning AR files, anchoring them in the room and sharing the scene — built around the
dashboard layout you supplied, re-skinned from purple to **sky blue** with **yellow** accents.

Everything lives in a single self-contained file: **`index.html`** (no build step, no external fonts, CDNs or images —
so it works from a double-click, inside the Arena preview, or from any static host).

---

## What's inside

### 1. Dashboard (your reference layout, re-skinned)
- Sky-blue icon rail with hover tooltips, yellow badge + active-state treatments
- "Hi, James! What will you scan today?" hero, an "Accuracy / Scans / Scenes" stat row
- Dashed **New scene** tile with the animated **+** button
- Three illustrated feature cards: **Scan AR files · Anchor & place · Collaborate & share**
- **Scanner feed** (notifications equivalent), **Active scenes** with anchor progress, due chips and viewers
- **Today's scans** with animated progress bars, avatars and view/anchor meta
- **Everything on** gradient card (sky-blue block, yellow CTA, all features included — nothing is gated) + two animated donut stats + **Board meeting** card

### 2. Scanner (the actual AR flow)
1. Opens your environment camera (`getUserMedia`). If the camera is blocked or unavailable (e.g. inside a sandboxed
   iframe), it falls back to an animated **simulated feed** and says so in the top-left chip.
2. Sweeping scan-line + AR brackets; after ~2s a marker is "recognised" and the matched file is reported.
3. **Place in scene** anchors a 3D model on the floor plane: levitating model, contact shadow, dashed tracking ring.
4. Live controls: swap model (Crystal / Cube / Pyramid / Pod / Ring), scale slider, anchor type (floor / image marker /
   face / geo point), auto-spin toggle, reset, drag-to-orbit, **Capture** (composites camera + AR into a PNG download)
   and **Share scene** (link).
5. **Print marker** generates a real Unipod marker (canvas-drawn, downloadable at 1200×1200 PNG) so you have something
   physical to point the camera at.

### 3. AR library
Upload or drag-and-drop `.glb`, `.gltf`, `.usdz`, `.reality`, `.obj` or marker `.zip` bundles → a card is created with an
auto-generated marker. Filters (all / 3D models / markers / scenes / drafts), live search, and per-file **Scan** /
**Open**. Every thumbnail is a real render of the model (canvas 2D low-poly renderer, no three.js needed).

### 4. Scenes, Insights, Team, Settings
- **Scenes**: deployed experiences per location, share links, "Enter AR"
- **Insights**: scans-per-day bar chart, tracking health bars, top AR files, device mix
- **Team**: roster with scanning status
- **Settings**: scanner/anchoring toggles, account summary (all features enabled by default, no tiers)

Every capability in the app is free and unlabelled: unlimited anchors and markers, 4K captures, shared marker
libraries, all anchor types and viewer links. There are no upgrade prompts, paywalls or "pro" badges anywhere.

### 5. Also included
- **Light / Dark themes** (persisted to `localStorage`, respects `prefers-color-scheme` on first visit)
- **Export data** → downloads `unipod-ar-export.json`
- Toasts, modal system, keyboard shortcuts (`⌘K` / `Ctrl-K` search, `Esc` closes scanner/modal)
- Fully responsive at 1440 / 1024 / 390 px (mobile converts the rail to a compact icon bar and hides the top tabs)

---

## Version control

Already initialised as a git repo (branch `main`, one clean commit) with `.gitignore`, `.gitattributes` and two
optional GitHub Actions workflows (deploy to Vercel, hourly `/api/health` smoke test).
See **[`CONNECT-TO-GIT.md`](CONNECT-TO-GIT.md)** for the copy-paste commands to push it to GitHub / GitLab / Bitbucket
and to let Vercel redeploy on every push.

## Backend

There is exactly one server-side piece, by design: **`api/health.js`**, a dependency-free Vercel Node function.

```
GET /api/health → { "status": "ok", "service": "unipod-ar", "version": "1.0.0",
                    "region": "fra1", "deployment": "production",
                    "runtime": "node v20.x", "uptime": 42, "timestamp": "…" }
```

The app calls it on load and whenever Settings opens, and shows the result at **Settings → Account → API health**
(`Online · fra1` in green, or `Static mode` in amber if it can't be reached — the app keeps working either way,
because every feature is client-side). Everything else — library, markers, captures, themes, scan counts — is
browser-side, persisted in `localStorage`.

## Deploy it

Already deployed once as a temporary preview from this workspace — see **[`DEPLOY.md`](DEPLOY.md)** for the live URL,
the 60-minute claim link, and the three ways to publish it permanently (Vercel CLI, GitHub import, drag & drop).
`vercel.json` is set up for zero-build static hosting with the camera permissions header already in place.

## Run it

```bash
# simplest: double-click index.html
# or serve it (camera needs https:// or localhost)
python3 -m http.server 8000
# open http://localhost:8000
```

Camera notes:
- Browsers only grant camera access on `localhost` or **HTTPS**.
- The Arena in-app preview runs in a sandboxed iframe with no camera permission — you'll see the simulated feed there.
  Download the file and open it directly (or host it) for the real camera path.

---

## Design tokens

| Token | Value |
|---|---|
| Primary sky | `#0EA5E9` (rail gradient `#38BDF8 → #0284C7`) |
| Sky tints | `#F0FAFF` `#DEF4FE` `#BCE7FD` `#7DD3FC` |
| Yellow sparks | `#FFD24C` (hover `#FFE28A`, deep `#F7B500`) |
| Ink / muted | `#0B1526` / `#6B7C93` |
| Surfaces | `#EEF4FA` page, `#FFFFFF` cards, `#E4EDF6` borders |
| Radius | 28 / 22 / 16 / 12 px · shadows are soft-sky, never black |

Typography: system UI stack, `-0.03em` tracking on headings, 700–800 weights for titles.

---

## Going from demo to production AR

The UI, data model, upload flow and rendering here are real; the marker *tracking* is a simulation (it can't read a
marker out of a video frame without a tracking engine). To make it track for real, swap the detection step in
`openScanner()`:

- **WebXR** — `navigator.xr.requestSession('immersive-ar')` + `hit-test` for plane anchoring (Android Chrome / Quest).
- **MindAR / jsartoolkit** — image-target tracking in the browser, good for printed markers like the one the app generates.
- **model-viewer / `<model-viewer ar>`** — quickest path for `ios-src` / `src` GLB + USDZ plus Quick Look on iOS.
- **Zapworks / 8th Wall / Vuforia** — the closest 1:1 replacement for Zapworks' marker + face + geo anchor types, and
  the natural upgrade path if you want the exact Zapworks feature set.

Model files are referenced as a small set of procedural meshes (`MODELS` object) so the demo has zero network
dependencies; point those at real `.glb` URLs (and a GLTF loader) when you connect your library.
