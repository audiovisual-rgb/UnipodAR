# Deploying Unipod AR to Vercel

The app is a **single static file** (`index.html`) — no build step, no dependencies, no environment variables.
That means it deploys to Vercel's free static hosting in one step and lands at `https://<project>.vercel.app`.

Files that matter:

| File | Purpose |
|---|---|
| `index.html` | the whole app (UI + logic + 3D renderer, all inline) |
| `vercel.json` | zero-build static config: `cleanUrls`, cache + security headers, and `Permissions-Policy: camera=(self)` so the scanner can use the device camera |
| `api/health.js` | serverless function — `GET /api/health` returns JSON status used by the app's Settings screen |
| `package.json` / `scripts/` | optional minified `dist/` build + a local dev server that emulates Vercel (static + `/api/health`) |
| `.vercelignore` | keeps `previews/`, `uploads/` and the README out of the deployment |

---

## Deploy status

| Item | State |
|---|---|
| Vercel connector | connected ✅ (account `umaulidi-9411`, team `team_dHSndjJk2qwOA5We4mX3JPKr`) |
| Earlier anonymous preview (`snappy-timpani-hvtv7ig.tmp.now`) | **expired** — anonymous temp deployments last 60 min and are now blocked from this machine |
| Project on your account | none yet — needs one authenticated push |
| Build + backend | verified locally (see `VERIFICATION.md`) |

One command publishes it to your account:

```bash
cd unipod-ar && npm run deploy      # = vercel deploy --prod
```

…or paste a Vercel token (vercel.com/account/tokens) into the chat and the deploy can be run from here.

---

## Option A — Vercel CLI (fastest, ~30 seconds)

```bash
cd unipod-ar                   # the folder containing index.html + vercel.json
npx vercel login               # once, if you're not logged in
npx vercel --prod              # deploy to production
```

First run asks three questions — answer with:

| Prompt | Answer |
|---|---|
| Set up and deploy? | `y` |
| Which scope? | your personal account |
| Link to existing project? | `n` |
| Project name? | `unipod-ar` |
| In which directory is your code located? | `./` |
| Want to modify these settings? | `n` |

The CLI prints the production URL. Re-deploy later with `npx vercel --prod`.

Non-interactive (CI or from another machine):

```bash
npx vercel deploy --prod --yes --token $VERCEL_TOKEN
```

---

## Option B — GitHub import (best for ongoing work)

```bash
cd /path/to/unipod-ar
git init && git add . && git commit -m "Unipod AR"
git branch -M main
git remote add origin https://github.com/<you>/unipod-ar.git
git push -u origin main
```

Then on [vercel.com/new](https://vercel.com/new) → **Import Git Repository** → pick the repo → leave
**Framework Preset: Other**, build command empty, output directory `./` → **Deploy**.
Every push to `main` re-deploys automatically.

---

## Option C — Drag & drop (no account wiring, no CLI)

Go to [vercel.com/new](https://vercel.com/new), choose **Deploy without Git**, and drag the project folder in.
Done.

---

## Verify the deployment

```bash
curl -i https://<your-project>.vercel.app/api/health     # {"status":"ok",...}
open https://<your-project>.vercel.app                   # Settings → Account → API health: Online · <region>
```

## After deploying — two things to check

1. **Camera on HTTPS.** Vercel gives you HTTPS by default, so `getUserMedia` works. Open the site on a phone to test
   the real scanner; on desktop the rear-camera hint still resolves to whatever webcam exists.
2. **Embedding.** If you put the app inside someone else's `<iframe>`, add `allow="camera; fullscreen"` to the iframe
   tag — the `Permissions-Policy` header only covers top-level use.

## Custom domain

Vercel dashboard → your project → **Settings → Domains → Add**, then point the DNS record Vercel shows you
(`A 76.76.21.21` for an apex domain, or `CNAME cname.vercel-dns.com` for `www` / subdomains).
