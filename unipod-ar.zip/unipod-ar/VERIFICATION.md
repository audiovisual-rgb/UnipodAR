# Verification report — Unipod AR

Run on a production-equivalent server: `node scripts/dev.mjs` serves the minified `dist/` build and answers
`GET /api/health` with the exact same handler Vercel runs, through a real Chromium browser (Playwright).

## Frontend

| Check | Result |
|---|---|
| Page loads | `HTTP 200`, title `Unipod AR — Scan, place & share augmented reality` |
| Dashboard renders | 17 cards/tiles/feature blocks |
| 3D thumbnails | canvas painted (non-empty pixels) |
| Scanner detection | marker recognised after scan pass ✅ |
| AR placement | `.placed` state reached, 3D model rendered to canvas ✅ |
| Capture | downloaded `unipod-ar-capture.png` (camera/AR composite) ✅ |
| Upload AR file | new card created from `.glb` upload ✅ |
| Theme persistence | dark theme survived reload (`localStorage`) ✅ |
| Marker print | downloaded `unipod-marker.png` (1200×1200) ✅ |
| Mobile 390 px | no horizontal scroll ✅ |
| Console errors | **none** |
| Network requests | `/`, `/styles.css`, `/app.js`, `/api/health` — nothing third-party |

## Backend

```
GET /api/health → 200
content-type: application/json; charset=utf-8
cache-control: no-store, max-age=0
{"status":"ok","service":"unipod-ar","version":"1.0.0","region":"local",
 "deployment":"development","runtime":"node v20.20.2","uptime":2,
 "timestamp":"2026-11-20T12:46:32.251Z"}
```

| Check | Result |
|---|---|
| Endpoint responds | `200` JSON ✅ |
| CORS / preflight | `Access-Control-Allow-Origin: *`, `OPTIONS → 204` ✅ |
| Wrong method | `405` with JSON error ✅ |
| App integration | Settings → Account → **API health: Online · local**, green dot ✅ |
| No backend available (file://) | gracefully degrades to **Static mode**, no errors ✅ |
| Env vars / DB required | none |

## How to re-run

```bash
cd unipod-ar
npm install          # esbuild only, for the minified dist build
npm run build        # optional: regenerates dist/
npm run dev          # http://localhost:8898 (+ /api/health)
```

Then open the site, go to **Settings → Account** and watch the *API health* row resolve to `Online · <region>`.
